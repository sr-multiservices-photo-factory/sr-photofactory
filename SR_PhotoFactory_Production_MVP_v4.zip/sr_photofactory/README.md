# एस आर मल्टिसरविसेस अँड फोटोफॅक्टरी — Production MVP v4

## काय तयार आहे
- प्रत्येक Wedding/Event साठी unique secure QR token
- QR मध्ये password नाही
- QR/ID + password verification
- PostgreSQL persistence
- Customer JWT gallery session
- Customer ला फक्त watermarked preview/thumbnail URLs
- Original files server storage मध्ये admin-only
- Select / Reject + selection limit
- Final submission lock + unique Selection ID
- Admin login API
- Admin event creation
- Admin photo upload with automatic preview watermark + thumbnail
- Delivery status API

## सुरू करण्याची पद्धत
1. Docker Desktop install करा.
2. या folder मध्ये `docker compose up --build` चालवा.
3. Database schema आपोआप तयार होईल.
4. Production मध्ये `JWT_SECRET` बदलणे आवश्यक आहे.

## Admin user
Production deployment आधी admins table मध्ये bcrypt password hash असलेला admin insert करा. Demo/default password repository मध्ये ठेवलेले नाही.

## Flutter
`customer_flutter` हा customer app आहे. API base URL `lib/main.dart` मधील `apiBase` मध्ये तुमच्या server चा HTTPS address द्या.

## Security note
Android screenshot/screen recording पूर्णपणे थांबवण्याची हमी कोणतेही app देऊ शकत नाही. App-level screenshot protection पुढच्या native Android hardening मध्ये जोडता येईल.
